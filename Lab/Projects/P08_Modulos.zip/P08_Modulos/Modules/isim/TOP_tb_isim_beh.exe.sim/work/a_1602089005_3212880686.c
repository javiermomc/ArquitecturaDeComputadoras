/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//vboxsrv/VM_ARQUI/ArquitecturaDeComputadoras/Lab/Projects/P08_Modulos/Modules/RAM.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1258338084_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_1602089005_3212880686_p_0(char *t0)
{
    char t16[16];
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    int t21;
    int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;

LAB0:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB13;

LAB14:    t1 = (unsigned char)0;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:
LAB3:    t2 = (t0 + 2228);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(58, ng0);
    t7 = (t0 + 868U);
    t8 = *((char **)t7);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    if (t10 != 0)
        goto LAB8;

LAB10:
LAB9:    goto LAB3;

LAB5:    t2 = (t0 + 752U);
    t6 = ieee_p_2592010699_sub_1258338084_503743352(IEEE_P_2592010699, t2, 0U, 0U);
    t1 = t6;
    goto LAB7;

LAB8:    xsi_set_current_line(59, ng0);
    t7 = (t0 + 1052U);
    t11 = *((char **)t7);
    t7 = (t0 + 684U);
    t12 = *((char **)t7);
    t13 = (31 - 6);
    t14 = (t13 * 1U);
    t15 = (0 + t14);
    t7 = (t12 + t15);
    t17 = (t16 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 6;
    t18 = (t17 + 4U);
    *((int *)t18) = 2;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (2 - 6);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t21 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t7, t16);
    t22 = (t21 - 31);
    t20 = (t22 * -1);
    t23 = (32U * t20);
    t24 = (0U + t23);
    t18 = (t0 + 2272);
    t25 = (t18 + 32U);
    t26 = *((char **)t25);
    t27 = (t26 + 40U);
    t28 = *((char **)t27);
    memcpy(t28, t11, 32U);
    xsi_driver_first_trans_delta(t18, t24, 32U, 0LL);
    xsi_set_current_line(60, ng0);
    t2 = xsi_get_transient_memory(32U);
    memset(t2, 0, 32U);
    t3 = t2;
    memset(t3, (unsigned char)2, 32U);
    t7 = (t0 + 2308);
    t8 = (t7 + 32U);
    t11 = *((char **)t8);
    t12 = (t11 + 40U);
    t17 = *((char **)t12);
    memcpy(t17, t2, 32U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB9;

LAB11:    xsi_set_current_line(63, ng0);
    t2 = (t0 + 1236U);
    t8 = *((char **)t2);
    t2 = (t0 + 684U);
    t11 = *((char **)t2);
    t13 = (31 - 6);
    t14 = (t13 * 1U);
    t15 = (0 + t14);
    t2 = (t11 + t15);
    t12 = (t16 + 0U);
    t17 = (t12 + 0U);
    *((int *)t17) = 6;
    t17 = (t12 + 4U);
    *((int *)t17) = 2;
    t17 = (t12 + 8U);
    *((int *)t17) = -1;
    t19 = (2 - 6);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t17 = (t12 + 12U);
    *((unsigned int *)t17) = t20;
    t21 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t2, t16);
    t22 = (t21 - 31);
    t20 = (t22 * -1);
    xsi_vhdl_check_range_of_index(31, 0, -1, t21);
    t23 = (32U * t20);
    t24 = (0 + t23);
    t17 = (t8 + t24);
    t18 = (t0 + 2308);
    t25 = (t18 + 32U);
    t26 = *((char **)t25);
    t27 = (t26 + 40U);
    t28 = *((char **)t27);
    memcpy(t28, t17, 32U);
    xsi_driver_first_trans_fast_port(t18);
    goto LAB3;

LAB13:    t2 = (t0 + 960U);
    t7 = *((char **)t2);
    t6 = *((unsigned char *)t7);
    t9 = (t6 == (unsigned char)3);
    t1 = t9;
    goto LAB15;

}


extern void work_a_1602089005_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1602089005_3212880686_p_0};
	xsi_register_didat("work_a_1602089005_3212880686", "isim/TOP_tb_isim_beh.exe.sim/work/a_1602089005_3212880686.didat");
	xsi_register_executes(pe);
}
