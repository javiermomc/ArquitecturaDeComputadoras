/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//vboxsrv/VM_ARQUI/ArquitecturaDeComputadoras/Lab/Projects/P08_Modulos/Modules/ALU.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_3620187407_sub_1742983514_3965413181(char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767668596_3965413181(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767740470_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_0832606739_3212880686_p_0(char *t0)
{
    char t24[16];
    char t40[16];
    char t42[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    int t11;
    char *t12;
    char *t13;
    int t14;
    char *t15;
    char *t16;
    int t17;
    char *t18;
    char *t19;
    int t20;
    char *t21;
    int t23;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned char t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t41;

LAB0:    t1 = (t0 + 1804U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 776U);
    t3 = *((char **)t2);
    t2 = (t0 + 4875);
    t5 = xsi_mem_cmp(t2, t3, 3U);
    if (t5 == 1)
        goto LAB5;

LAB13:    t6 = (t0 + 4878);
    t8 = xsi_mem_cmp(t6, t3, 3U);
    if (t8 == 1)
        goto LAB6;

LAB14:    t9 = (t0 + 4881);
    t11 = xsi_mem_cmp(t9, t3, 3U);
    if (t11 == 1)
        goto LAB7;

LAB15:    t12 = (t0 + 4884);
    t14 = xsi_mem_cmp(t12, t3, 3U);
    if (t14 == 1)
        goto LAB8;

LAB16:    t15 = (t0 + 4887);
    t17 = xsi_mem_cmp(t15, t3, 3U);
    if (t17 == 1)
        goto LAB9;

LAB17:    t18 = (t0 + 4890);
    t20 = xsi_mem_cmp(t18, t3, 3U);
    if (t20 == 1)
        goto LAB10;

LAB18:    t21 = (t0 + 4893);
    t23 = xsi_mem_cmp(t21, t3, 3U);
    if (t23 == 1)
        goto LAB11;

LAB19:
LAB12:    xsi_set_current_line(38, ng0);
    t2 = xsi_get_transient_memory(32U);
    memset(t2, 0, 32U);
    t3 = t2;
    memset(t3, (unsigned char)2, 32U);
    t4 = (t0 + 2500);
    t6 = (t4 + 32U);
    t7 = *((char **)t6);
    t9 = (t7 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 32U);
    xsi_driver_first_trans_fast(t4);

LAB4:    xsi_set_current_line(37, ng0);

LAB33:    t2 = (t0 + 2432);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB34;

LAB1:    return;
LAB5:    xsi_set_current_line(38, ng0);
    t25 = (t0 + 592U);
    t26 = *((char **)t25);
    t25 = (t0 + 4640U);
    t27 = (t0 + 684U);
    t28 = *((char **)t27);
    t27 = (t0 + 4656U);
    t29 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t24, t26, t25, t28, t27);
    t30 = (t24 + 12U);
    t31 = *((unsigned int *)t30);
    t32 = (1U * t31);
    t33 = (32U != t32);
    if (t33 == 1)
        goto LAB21;

LAB22:    t34 = (t0 + 2500);
    t35 = (t34 + 32U);
    t36 = *((char **)t35);
    t37 = (t36 + 40U);
    t38 = *((char **)t37);
    memcpy(t38, t29, 32U);
    xsi_driver_first_trans_fast(t34);
    goto LAB4;

LAB6:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t2 = (t0 + 4640U);
    t4 = (t0 + 684U);
    t6 = *((char **)t4);
    t4 = (t0 + 4656U);
    t7 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t24, t3, t2, t6, t4);
    t9 = (t24 + 12U);
    t31 = *((unsigned int *)t9);
    t32 = (1U * t31);
    t33 = (32U != t32);
    if (t33 == 1)
        goto LAB23;

LAB24:    t10 = (t0 + 2500);
    t12 = (t10 + 32U);
    t13 = *((char **)t12);
    t15 = (t13 + 40U);
    t16 = *((char **)t15);
    memcpy(t16, t7, 32U);
    xsi_driver_first_trans_fast(t10);
    goto LAB4;

LAB7:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t2 = (t0 + 4640U);
    t4 = (t0 + 684U);
    t6 = *((char **)t4);
    t4 = (t0 + 4656U);
    t7 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t24, t3, t2, t6, t4);
    t9 = (t24 + 12U);
    t31 = *((unsigned int *)t9);
    t32 = (1U * t31);
    t33 = (32U != t32);
    if (t33 == 1)
        goto LAB25;

LAB26:    t10 = (t0 + 2500);
    t12 = (t10 + 32U);
    t13 = *((char **)t12);
    t15 = (t13 + 40U);
    t16 = *((char **)t15);
    memcpy(t16, t7, 32U);
    xsi_driver_first_trans_fast(t10);
    goto LAB4;

LAB8:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t2 = (t0 + 2500);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t9 = *((char **)t7);
    memcpy(t9, t3, 32U);
    xsi_driver_first_trans_fast(t2);
    goto LAB4;

LAB9:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 684U);
    t3 = *((char **)t2);
    t31 = (31 - 15);
    t32 = (t31 * 1U);
    t39 = (0 + t32);
    t2 = (t3 + t39);
    t4 = (t0 + 4896);
    t9 = ((IEEE_P_2592010699) + 2332);
    t10 = (t40 + 0U);
    t12 = (t10 + 0U);
    *((int *)t12) = 15;
    t12 = (t10 + 4U);
    *((int *)t12) = 0;
    t12 = (t10 + 8U);
    *((int *)t12) = -1;
    t5 = (0 - 15);
    t41 = (t5 * -1);
    t41 = (t41 + 1);
    t12 = (t10 + 12U);
    *((unsigned int *)t12) = t41;
    t12 = (t42 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 0;
    t13 = (t12 + 4U);
    *((int *)t13) = 15;
    t13 = (t12 + 8U);
    *((int *)t13) = 1;
    t8 = (15 - 0);
    t41 = (t8 * 1);
    t41 = (t41 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t41;
    t7 = xsi_base_array_concat(t7, t24, t9, (char)97, t2, t40, (char)97, t4, t42, (char)101);
    t41 = (16U + 16U);
    t33 = (32U != t41);
    if (t33 == 1)
        goto LAB27;

LAB28:    t13 = (t0 + 2500);
    t15 = (t13 + 32U);
    t16 = *((char **)t15);
    t18 = (t16 + 40U);
    t19 = *((char **)t18);
    memcpy(t19, t7, 32U);
    xsi_driver_first_trans_fast(t13);
    goto LAB4;

LAB10:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t2 = (t0 + 4640U);
    t4 = (t0 + 684U);
    t6 = *((char **)t4);
    t4 = (t0 + 4656U);
    t7 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t24, t3, t2, t6, t4);
    t9 = (t24 + 12U);
    t31 = *((unsigned int *)t9);
    t32 = (1U * t31);
    t33 = (32U != t32);
    if (t33 == 1)
        goto LAB29;

LAB30:    t10 = (t0 + 2500);
    t12 = (t10 + 32U);
    t13 = *((char **)t12);
    t15 = (t13 + 40U);
    t16 = *((char **)t15);
    memcpy(t16, t7, 32U);
    xsi_driver_first_trans_fast(t10);
    goto LAB4;

LAB11:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 1144U);
    t3 = *((char **)t2);
    t2 = (t0 + 2500);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t9 = *((char **)t7);
    memcpy(t9, t3, 32U);
    xsi_driver_first_trans_fast(t2);
    goto LAB4;

LAB20:;
LAB21:    xsi_size_not_matching(32U, t32, 0);
    goto LAB22;

LAB23:    xsi_size_not_matching(32U, t32, 0);
    goto LAB24;

LAB25:    xsi_size_not_matching(32U, t32, 0);
    goto LAB26;

LAB27:    xsi_size_not_matching(32U, t41, 0);
    goto LAB28;

LAB29:    xsi_size_not_matching(32U, t32, 0);
    goto LAB30;

LAB31:    t3 = (t0 + 2432);
    *((int *)t3) = 0;
    goto LAB2;

LAB32:    goto LAB31;

LAB34:    goto LAB32;

}

static void work_a_0832606739_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    unsigned char t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 4640U);
    t3 = (t0 + 684U);
    t4 = *((char **)t3);
    t3 = (t0 + 4656U);
    t5 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t2, t1, t4, t3);
    if (t5 != 0)
        goto LAB3;

LAB4:
LAB5:    t13 = (t0 + 4944);
    t15 = (t0 + 2536);
    t16 = (t15 + 32U);
    t17 = *((char **)t16);
    t18 = (t17 + 40U);
    t19 = *((char **)t18);
    memcpy(t19, t13, 32U);
    xsi_driver_first_trans_fast(t15);

LAB2:    t20 = (t0 + 2440);
    *((int *)t20) = 1;

LAB1:    return;
LAB3:    t6 = (t0 + 4912);
    t8 = (t0 + 2536);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t6, 32U);
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_0832606739_3212880686_p_2(char *t0)
{
    char t5[16];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 1052U);
    t2 = *((char **)t1);
    t1 = (t0 + 4704U);
    t3 = (t0 + 4976);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 31;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (31 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB3;

LAB4:
LAB5:    t15 = (t0 + 2572);
    t16 = (t15 + 32U);
    t17 = *((char **)t16);
    t18 = (t17 + 40U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t15);

LAB2:    t20 = (t0 + 2448);
    *((int *)t20) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 2572);
    t11 = (t7 + 32U);
    t12 = *((char **)t11);
    t13 = (t12 + 40U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_0832606739_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(48, ng0);

LAB3:    t1 = (t0 + 1052U);
    t2 = *((char **)t1);
    t1 = (t0 + 2608);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 2456);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0832606739_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0832606739_3212880686_p_0,(void *)work_a_0832606739_3212880686_p_1,(void *)work_a_0832606739_3212880686_p_2,(void *)work_a_0832606739_3212880686_p_3};
	xsi_register_didat("work_a_0832606739_3212880686", "isim/TOP_tb_isim_beh.exe.sim/work/a_0832606739_3212880686.didat");
	xsi_register_executes(pe);
}
